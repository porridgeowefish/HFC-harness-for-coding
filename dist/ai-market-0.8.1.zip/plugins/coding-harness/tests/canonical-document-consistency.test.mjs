import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const plugin = join(dirname(fileURLToPath(import.meta.url)), '..');
const repository = resolve(plugin, '..', '..');

async function collect(root) {
  const files = [];
  async function visit(path) {
    for (const entry of await readdir(path, { withFileTypes: true })) {
      const target = join(path, entry.name);
      if (entry.isDirectory()) await visit(target); else files.push(target);
    }
  }
  await visit(root); return files;
}

test('current design documents use one generated layout and distinguish the HTML simulation', async () => {
  const technical = await readFile(join(repository, '技术设计-流程模块与交接协议.md'), 'utf8');
  const adr = await readFile(join(repository, 'ADR-latest.md'), 'utf8');
  const html = await readFile(join(repository, 'AI-dev-harness.html'), 'utf8');
  for (const token of ['onboarding-checklist.json', 'knowledge-update-review.md', '.gitignore']) {
    assert.match(technical, new RegExp(token.replaceAll('.', '\\.')));
    assert.match(adr, new RegExp(token.replaceAll('.', '\\.')));
    assert.match(html, new RegExp(token.replaceAll('.', '\\.')));
  }
  assert.doesNotMatch(adr, /\.codebuddy\/checklist\.json|\.githooks\/pre-commit|node \.codebuddy\/scripts\/harness\.mjs|└── constraints\/|"constraints"\s*:/);
  assert.match(html, /11 份 workflow 文件（9 个展示页签）/);
  assert.match(technical, /development-contract\.md/);
  assert.match(adr, /development-contract\.md/);
  assert.match(html, /development-contract\.md/);
  assert.match(html, /Workflow 非模板模拟/);
  assert.match(html, /workflows\/<\/b>[\s\S]*README\.md/);
});

test('the active plugin contract contains no content digest mechanism', async () => {
  const roots = ['runtime', 'schemas', 'templates'].map((name) => join(plugin, name));
  for (const root of roots) for (const path of await collect(root)) {
    const text = await readFile(path, 'utf8');
    assert.doesNotMatch(text, /contentDigest|artifactDigest|sha256|createHash/, path);
  }
});

test('release documentation marks v0.7 historical and keeps the v0.8 artifact order', async () => {
  const readme = await readFile(join(repository, 'README.md'), 'utf8');
  const oldSpec = await readFile(join(repository, 'docs', 'superpowers', 'specs', '2026-09-09-v07-distributed-initialization-and-markdown-contract.md'), 'utf8');
  const workflowReadme = await readFile(join(plugin, 'templates', 'workflow', 'README.md'), 'utf8');
  assert.match(oldSpec, /历史版本，已被 0\.8\.0 取代/);
  assert.match(oldSpec, /历史口径（已失效）/);
  assert.match(readme, /0\.7\.0 初始化设计.*仅保留为历史记录/);
  const positions = ['design-decision.md', 'development-contract.md', 'task-package.md'].map((name) => workflowReadme.indexOf(name));
  assert.ok(positions.every((position, index) => position >= 0 && (index === 0 || position > positions[index - 1])));
});
